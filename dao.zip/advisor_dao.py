from services.db_utils import DBConnection

def get_advisor_by_id(advisor_id):
    connection = DBConnection.get_connection()
    try:
        cursor = connection.cursor()
        query = "SELECT * FROM advisor WHERE advisor_id = ?"
        cursor.execute(query, (advisor_id,))
        row = cursor.fetchone()
        if row:
            columns = [desc[0] for desc in cursor.description]
            return dict(zip(columns, row))
        return None
    except Exception as e:
        print(f"Error fetching advisor by ID: {e}")
        return None
    finally:
        cursor.close()
        connection.close()
