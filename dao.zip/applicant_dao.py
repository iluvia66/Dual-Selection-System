from services.db_utils import DBConnection

class ApplicantDAO:
    @staticmethod
    def get_all_candidates() -> list:
        """
        从数据库获取所有候选人数据
        :return: 候选人信息的字典列表
        """
        connection = None
        try:
            connection = DBConnection.get_connection()
            cursor = connection.cursor()
            query = "SELECT * FROM Candidate"  # 查询 Candidate 表的所有记录
            cursor.execute(query)
            columns = [column[0] for column in cursor.description]  # 获取列名
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]  # 返回字典列表
            print(f"DAO: Retrieved {len(results)} candidates")  # 调试日志
            return results
        except Exception as e:
            print(f"DAO Error: {str(e)}")  # 错误日志
            raise Exception(f"查询 Candidate 表失败: {str(e)}")
        finally:
            if connection:
                connection.close()  # 确保数据库连接关闭
    @staticmethod
    def get_candidate_exam_view() -> list:
        """
        从 Candidate_Exam_View 获取数据
        """
        connection = None
        try:
            connection = DBConnection.get_connection()
            cursor = connection.cursor()
            query = """
                   SELECT candidate_id, candidate_name, gender, birthdate, candidate_id_num, candidate_email,
                          candidate_phone, nationality, applying_major, firtest_subject_name, firtest_date,
                          firtest_score, retest_subject_name, retest_subject_description, retest_date, retest_location,
                          oral_exam_score, professional_knowledge_score, comprehensive_ability_score
                   FROM Candidate_Exam_View
               """
            cursor.execute(query)
            columns = [column[0] for column in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]
            return results
        except Exception as e:
            raise Exception(f"查询 Candidate_Exam_View 失败: {str(e)}")
        finally:
            if connection:
                connection.close()

    @staticmethod
    def apply_sift_rule() -> None:
        """
        根据规则筛选复试成绩并更新 sift 列
        """
        connection = None
        try:
            connection = DBConnection.get_connection()
            cursor = connection.cursor()
            query = """
                UPDATE Retest_Info
                SET sift = CASE
                    WHEN oral_exam_score > 75
                     AND professional_knowledge_score > 75
                     AND comprehensive_ability_score > 75 THEN 1
                    ELSE 0
                END;
            """
            cursor.execute(query)
            connection.commit()  # 提交事务
        except Exception as e:
            raise Exception(f"更新 Retest_Info 表 sift 列失败: {str(e)}")
        finally:
            if connection:
                connection.close()  # 确保数据库连接关闭

    @staticmethod
    def fetch_retest_info() -> list:
        """
        获取 Retest_Info 表的所有数据
        :return: Retest_Info 表数据的字典列表
        """
        connection = None
        try:
            connection = DBConnection.get_connection()
            cursor = connection.cursor()
            query = "SELECT * FROM Retest_Info"  # 查询 Retest_Info 表的所有记录
            cursor.execute(query)
            columns = [column[0] for column in cursor.description]  # 获取列名
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]  # 返回字典列表
            return results
        except Exception as e:
            raise Exception(f"查询 Retest_Info 表失败: {str(e)}")
        finally:
            if connection:
                connection.close()  # 确保数据库连接关闭

    @staticmethod
    def update_sift(candidate_id: int, sift_value: int) -> bool:
        """
        更新 Retest_Info 表中指定 candidate_id 的 sift 列
        :param candidate_id: 候选人 ID
        :param sift_value: sift 值 (0 或 1)
        :return: 是否成功更新
        """
        connection = None
        try:
            connection = DBConnection.get_connection()
            cursor = connection.cursor()
            query = """
                UPDATE Retest_Info
                SET sift = ?
                WHERE candidate_id = ?
            """
            cursor.execute(query, (sift_value, candidate_id))
            connection.commit()  # 提交事务
            return cursor.rowcount > 0  # 返回是否成功更新
        except Exception as e:
            raise Exception(f"更新 sift 列失败: {str(e)}")
        finally:
            if connection:
                connection.close()  # 确保数据库连接关闭

    def get_sift_1_students_with_advisors():
        query = """
        SELECT 
            c.candidate_id,
            c.name,
            c.gender,
            c.birthdate,
            c.email,
            c.phone,
            c.applying_major,
            MAX(CASE WHEN pm.preference_order = 1 THEN a.name END) AS advisor1_name,
            MAX(CASE WHEN pm.preference_order = 2 THEN a.name END) AS advisor2_name,
            MAX(CASE WHEN pm.preference_order = 3 THEN a.name END) AS advisor3_name
        FROM Candidate c
        JOIN Retest_Info r ON c.candidate_id = r.candidate_id
        LEFT JOIN Preference_Match pm ON c.candidate_id = pm.candidate_id
        LEFT JOIN advisor a ON pm.advisor_id = a.advisor_id
        WHERE r.sift = 1
        GROUP BY 
            c.candidate_id, 
            c.name, 
            c.gender, 
            c.birthdate, 
            c.email, 
            c.phone, 
            c.applying_major;
        """
        result = db.session.execute(query)
        return [dict(row) for row in result]