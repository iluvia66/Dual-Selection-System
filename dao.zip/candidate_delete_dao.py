from services.db_utils import DBConnection


class CandidateDeleteDAO:
    @staticmethod
    def get_sift_1_students() -> list:
        """
        获取 sift=1 的学生信息
        """
        connection = None
        try:
            connection = DBConnection.get_connection()
            cursor = connection.cursor()
            query = """
                SELECT Candidate.candidate_id, Candidate.name, Candidate.gender, Candidate.birthdate,
                       Candidate.id_number, Candidate.email, Candidate.phone, Candidate.nationality,
                       Candidate.exam_id, Candidate.degree, Candidate.undergrad_major,
                       Candidate.undergrad_school, Candidate.undergrad_type, Candidate.applying_major,
                       Candidate.exam_type, Retest_Info.oral_exam_score,
                       Retest_Info.professional_knowledge_score, Retest_Info.comprehensive_ability_score
                FROM Candidate
                JOIN Retest_Info ON Candidate.candidate_id = Retest_Info.candidate_id
                WHERE Retest_Info.sift = 1
            """
            cursor.execute(query)
            columns = [column[0] for column in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]
            return results
        except Exception as e:
            print("查询 sift=1 学生失败:", str(e))
            raise Exception(f"查询 sift=1 学生信息失败: {str(e)}")
        finally:
            if connection:
                connection.close()

