from services.db_utils import DBConnection


class RetestInfoDAO:
    @staticmethod
    @staticmethod
    def process_sift_logic():
        """
        模拟触发器逻辑：处理 sift=0 的学生数据迁移。
        """
        connection = None
        try:
            connection = DBConnection.get_connection()
            cursor = connection.cursor()

            # 查询 sift=0 的学生信息
            query_sift_0_candidates = """
                   SELECT c.candidate_id, c.name, c.gender, c.birthdate, c.id_number, c.email, c.phone,
                          c.nationality, c.exam_id, c.degree, c.undergrad_major, c.undergrad_school,
                          c.undergrad_type, c.applying_major, c.exam_type, r.firtest_score,
                          r.oral_exam_score, r.professional_knowledge_score, r.comprehensive_ability_score,
                          r.subject_id_1, r.subject_score_1, r.subject_id_2, r.subject_score_2,
                          r.subject_id_3, r.subject_score_3, r.subject_id_4, r.subject_score_4,
                          r.advisor_id_1, r.preference_order_1, r.advisor_id_2, r.preference_order_2,
                          r.advisor_id_3, r.preference_order_3
                   FROM Candidate c
                   JOIN Retest_Info r ON c.candidate_id = r.candidate_id
                   WHERE r.sift = 0
               """
            cursor.execute(query_sift_0_candidates)
            sift_0_candidates = cursor.fetchall()

            if not sift_0_candidates:
                print("没有符合条件的 sift=0 学生")
                return {"status": "success", "message": "没有符合条件的学生需要迁移"}

            # 遍历结果并迁移数据
            for candidate in sift_0_candidates:
                print(f"正在处理 candidate_id: {candidate[0]}")

                # 插入到 candidate_delete 表
                insert_query = """
                       INSERT INTO candidate_delete (
                           candidate_id, name, gender, birthdate, id_number, email, phone, nationality, exam_id, degree,
                           undergrad_major, undergrad_school, undergrad_type, applying_major, exam_type,
                           firtest_score, oral_exam_score, professional_knowledge_score, comprehensive_ability_score,
                           subject_id_1, subject_score_1, subject_id_2, subject_score_2,
                           subject_id_3, subject_score_3, subject_id_4, subject_score_4,
                           advisor_id_1, preference_order_1, advisor_id_2, preference_order_2,
                           advisor_id_3, preference_order_3
                       ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                   """
                cursor.execute(insert_query, candidate)
                print(f"Candidate ID {candidate[0]} 数据已迁移到 candidate_delete 表")

                # 删除原表中的数据
                delete_retest_query = "DELETE FROM Retest_Info WHERE candidate_id = %s"
                delete_candidate_query = "DELETE FROM Candidate WHERE candidate_id = %s"
                cursor.execute(delete_retest_query, (candidate[0],))
                cursor.execute(delete_candidate_query, (candidate[0],))
                print(f"Candidate ID {candidate[0]} 的原始数据已删除")

            connection.commit()
            print("所有符合条件的学生数据已成功迁移")
            return {"status": "success", "message": "所有符合条件的学生数据已成功迁移"}

        except Exception as e:
            if connection:
                connection.rollback()
            print("迁移过程中发生错误:", str(e))
            return {"status": "error", "message": str(e)}
        finally:
            if connection:
                connection.close()
