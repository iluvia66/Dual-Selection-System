from dao.retest_info_dao import RetestInfoDAO


class RetestInfoService:
    @staticmethod
    def process_sift_logic():
        """
        调用 DAO 层处理 sift=0 的逻辑
        """
        return RetestInfoDAO.process_sift_logic()
