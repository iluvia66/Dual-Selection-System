from dbutils.pooled_db import PooledDB
import pyodbc

class DBConnection:
    pool = PooledDB(
        creator=pyodbc.connect,
        maxconnections=10,
        mincached=2,
        maxcached=5,
        blocking=True,
        # 检查驱动参数是否正确
        driver='{ODBC Driver 17 for SQL Server}',
        server='localhost',  # 确保这里的服务器地址正确
        database='dual_selection_system',  # 数据库名称
        uid='sa',  # 数据库用户名
        pwd='041206wty'  # 数据库密码
    )

    @classmethod
    def get_connection(cls):
        """从连接池中获取一个数据库连接"""
        try:
            connection = cls.pool.connection()
            print("Database connection successful")  # 调试信息
            return connection
        except pyodbc.Error as e:
            print(f"数据库连接失败: {e}")
            raise e
if __name__ == "__main__":
    try:
        connection = DBConnection.get_connection()
        cursor = connection.cursor()
        cursor.execute("SELECT 1")  # 测试简单查询
        print("Database connected successfully!")
        connection.close()
    except Exception as e:
        print(f"Database connection test failed: {str(e)}")
