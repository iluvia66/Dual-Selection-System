from dao.candidate_delete_dao import CandidateDeleteDAO
from  services.db_utils import DBConnection

class CandidateDeleteService:
    @staticmethod
    def get_sift_1_students():
        query = """
        SELECT 
            c.candidate_id,
            c.name,
            c.gender,
            c.birthdate,
            c.email,
            c.phone,
            c.applying_major,
            MAX(CASE WHEN pm.preference_order = 1 THEN a.name END) AS advisor1_name,
            MAX(CASE WHEN pm.preference_order = 2 THEN a.name END) AS advisor2_name,
            MAX(CASE WHEN pm.preference_order = 3 THEN a.name END) AS advisor3_name
        FROM Candidate c
        JOIN Retest_Info r ON c.candidate_id = r.candidate_id
        LEFT JOIN Preference_Match pm ON c.candidate_id = pm.candidate_id
        LEFT JOIN advisor a ON pm.advisor_id = a.advisor_id
        WHERE r.sift = 1
        GROUP BY 
            c.candidate_id, 
            c.name, 
            c.gender, 
            c.birthdate, 
            c.email, 
            c.phone, 
            c.applying_major;
        """
        connection = None
        try:
            connection = DBConnection.get_connection()
            with connection.cursor() as cursor:
                cursor.execute(query)
                results = cursor.fetchall()  # 获取查询结果
                print(f"Debug: Retrieved {len(results)} students with advisors")  # 调试信息
                return results
        except Exception as e:
            print(f"Error executing query: {str(e)}")
            raise
        finally:
            if connection:
                connection.close()  # 确保关闭数据库连接
