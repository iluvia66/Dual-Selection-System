from services.db_utils import DBConnection

def process_student_input(student_data):
    connection = DBConnection.get_connection()
    cursor = connection.cursor()
    try:
        print("Received student data:", student_data)

        # 插入 Candidate 表
        insert_candidate_query = """
        INSERT INTO Candidate (candidate_id, name, gender, birthdate, id_number, email, phone, nationality)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """
        cursor.execute(insert_candidate_query, (
            student_data.get('candidate_id'),
            student_data.get('name'),
            student_data.get('gender'),
            student_data.get('birthdate'),
            student_data.get('id_number'),
            student_data.get('email'),
            student_data.get('phone'),
            student_data.get('nationality'),
        ))

        # 插入 Retest_Info 表
        insert_retest_query = """
        INSERT INTO Retest_Info (retest_id, candidate_id, subject_name, subject_description, retake_date, 
                                 retest_location, oral_exam_score, professional_knowledge_score, comprehensive_ability_score, sift)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        cursor.execute(insert_retest_query, (
            student_data.get('retest_id'),
            student_data.get('candidate_id'),
            student_data.get('subject_name'),
            student_data.get('subject_description'),
            student_data.get('retake_date'),
            student_data.get('retest_location'),
            student_data.get('oral_exam_score'),
            student_data.get('professional_knowledge_score'),
            student_data.get('comprehensive_ability_score'),
            student_data.get('sift'),
        ))

        # 插入 Advisor 表
        insert_advisor_query = """
        INSERT INTO Preference_Match (match_id, candidate_id, advisor_id, preference_order)
        VALUES (?, ?, ?, ?)
        """
        cursor.execute(insert_advisor_query, (
            student_data.get('match_id'),
            student_data.get('candidate_id'),
            student_data.get('advisor_id'),
            student_data.get('preference_order'),
        ))

        connection.commit()
        return "Data inserted successfully"

    except Exception as e:
        connection.rollback()
        raise Exception(f"Error in processing student input: {str(e)}")

    finally:
        cursor.close()
        connection.close()
