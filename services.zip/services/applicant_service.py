from dao.applicant_dao import ApplicantDAO
from services.db_utils import DBConnection

class ApplicantService:
    @staticmethod
    def get_all_candidates() -> list:
        """
        获取所有候选人的数据
        """
        try:
            candidates = ApplicantDAO.get_all_candidates()
            print(f"Service: Retrieved {len(candidates)} candidates")  # 调试日志
            print(f"Candidates Data: {candidates}")  # 打印数据
            return candidates
        except Exception as e:
            print(f"Service Error: {str(e)}")  # 错误日志
            raise Exception(f"获取候选人数据失败: {str(e)}")

    @staticmethod
    def fetch_candidate_exam_view() -> list:
        """
        获取 Candidate_Exam_View 中的数据
        """
        try:
            return ApplicantDAO.get_candidate_exam_view()
        except Exception as e:
            raise Exception(f"获取 Candidate_Exam_View 数据失败: {str(e)}")

    # @staticmethod
    # def get_candidate_exam_view() -> list:
    #     """
    #     获取 Candidate_Exam_View 中的数据
    #     :return: 包含视图信息的列表
    #     """
    #     try:
    #         return ApplicantDAO.get_candidate_exam_view()
    #     except Exception as e:
    #         raise Exception(f"获取 Candidate_Exam_View 数据失败: {str(e)}")

    @staticmethod
    def apply_sift() -> dict:
        """
        调用 DAO 方法应用筛选规则
        :return: 筛选规则应用结果的字典
        """
        try:
            ApplicantDAO.apply_sift_rule()
            return {"status": "success", "message": "筛选规则已成功应用"}
        except Exception as e:
            raise Exception(f"应用筛选规则失败: {str(e)}")

    @staticmethod
    def update_sift(candidate_id: int, sift_value: int) -> dict:
        """
        更新 Retest_Info 表中的 sift 值
        :param candidate_id: 候选人 ID
        :param sift_value: 要更新的 sift 值 (0 或 1)
        :return: 更新结果的字典
        """
        try:
            if sift_value not in [0, 1]:
                raise ValueError("sift 值只能是 0 或 1")
            success = ApplicantDAO.update_sift(candidate_id, sift_value)
            if success:
                return {"status": "success", "message": "sift 值更新成功"}
            else:
                return {"status": "error", "message": "更新失败，请检查 candidate_id 是否存在"}
        except Exception as e:
            raise Exception(f"更新 sift 值失败: {str(e)}")