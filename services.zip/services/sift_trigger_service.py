from services.db_utils import DBConnection


def fetch_deleted_candidates():
    """
    获取 candidate_delete 表中的所有已删除的候选人信息
    """
    connection = DBConnection()
    cursor = connection.cursor()
    try:
        query = """
        SELECT * FROM candidate_delete
        """
        cursor.execute(query)
        results = cursor.fetchall()
        # 格式化查询结果为字典
        column_names = [desc[0] for desc in cursor.description]
        deleted_candidates = [dict(zip(column_names, row)) for row in results]
        return deleted_candidates
    finally:
        cursor.close()
        connection.close()
