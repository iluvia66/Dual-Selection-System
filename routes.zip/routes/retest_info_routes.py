from flask import Blueprint, jsonify
from services.retest_info_service import RetestInfoService

retest_info_bp = Blueprint('retest_info', __name__)

@retest_info_bp.route('/process_sift_logic', methods=['POST'])
def process_sift_logic():
    """
    触发 sift=0 学生数据迁移逻辑
    """
    try:
        result = RetestInfoService.process_sift_logic()
        return jsonify(result), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
