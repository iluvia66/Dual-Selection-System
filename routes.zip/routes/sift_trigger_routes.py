from flask import Blueprint, render_template

sift_trigger_bp = Blueprint('sift_trigger', __name__)

@sift_trigger_bp.route('/view_deleted_candidates', methods=['GET'])
def view_deleted_candidates_page():
    """
    渲染已删除候选人列表的页面
    """
    return render_template('view_deleted_candidates.html')
