from flask import Blueprint, jsonify
from services.applicant_service import ApplicantService

exam_view_bp = Blueprint('exam_view', __name__)

@exam_view_bp.route('/candidate_exam_view', methods=['GET'])
def get_candidate_exam_view():
    """
    获取 Candidate_Exam_View 中的信息
    """
    try:
        data = ApplicantService.fetch_candidate_exam_view()
        return jsonify({'status': 'success', 'data': data})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@exam_view_bp.route('/apply_sift_rule', methods=['POST'])
def apply_sift_rule():
    """
    获取 Candidate_Exam_View 中的信息
    """
    try:
        data = ApplicantService.fetch_candidate_exam_view()  # 修改此处为 fetch_candidate_exam_view
        return jsonify({'status': 'success', 'data': data})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500
