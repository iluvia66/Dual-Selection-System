from flask import Blueprint, request, jsonify, render_template
from services.student_input_service import process_student_input

student_input_bp = Blueprint('student_input', __name__)

@student_input_bp.route('/input_student', methods=['GET'])
def input_student_page():
    """
    渲染学生信息输入页面
    """
    return render_template('input_student.html')

@student_input_bp.route('/process_student', methods=['POST'])
def process_student():
    """
    处理学生信息，根据 sift 值存入不同的表
    """
    student_data = request.json
    try:
        process_student_input(student_data)
        return jsonify({"message": "Student information processed successfully."}), 200
    except Exception as e:
        print(f"Error processing student information: {e}")
        return jsonify({"message": "Failed to process student information."}), 500
