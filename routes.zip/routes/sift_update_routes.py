from flask import Blueprint, request, jsonify
from services.applicant_service import ApplicantService

sift_update_bp = Blueprint('sift_update', __name__)

@sift_update_bp.route('/update_sift', methods=['POST'])
def update_sift():
    """
    更新 Retest_Info 表的 sift 值
    """
    try:
        # 从请求中获取数据
        data = request.get_json()
        candidate_id = data.get('candidate_id')
        sift_value = data.get('sift')

        if candidate_id is None or sift_value is None:
            return jsonify({'status': 'error', 'message': '缺少参数 candidate_id 或 sift'}), 400

        # 调用服务方法更新 sift 值
        result = ApplicantService.update_sift(candidate_id, sift_value)
        return jsonify(result)
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500
@sift_update_bp.route('/apply_sift_rule', methods=['POST'])
@sift_update_bp.route('/apply_sift_rule', methods=['POST'], endpoint='sift_update_apply_sift_rule')
def apply_sift_rule():
    """
    应用筛选规则，更新 sift 列
    """
    try:
        ApplicantService.apply_sift_rule()
        return jsonify({'status': 'success', 'message': '筛选规则已成功应用'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500
