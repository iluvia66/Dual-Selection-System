from flask import Blueprint, jsonify, render_template
from services.candidate_delete_service import CandidateDeleteService

candidate_delete_bp = Blueprint('candidate_delete', __name__)

@candidate_delete_bp.route('/view_sift_1_students', methods=['GET'])
def view_sift_1_students():
    """
    页面: 获取 sift=1 的学生信息，并在 HTML 页面中展示
    """
    try:
        sift_1_students = CandidateDeleteService.get_sift_1_students()
        print(f"Debug: Students passed to template: {sift_1_students}")
        return render_template('view_sift_1.html', students=sift_1_students)
    except Exception as e:
        print(f"Error: {str(e)}")
        return render_template('error.html', error_message=f"Error fetching sift=1 students: {str(e)}"), 500


@candidate_delete_bp.route('/view_sift_1', methods=['GET'])
def view_sift_1_alias():
    """
    页面: /view_sift_1 的别名
    """
    return view_sift_1_students()
