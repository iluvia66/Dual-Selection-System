from flask import Blueprint, render_template, request, redirect, url_for, flash
from services.user_service import register_user

register_bp = Blueprint('register', __name__)

@register_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        userid = request.form['userid']
        password = request.form['password']
        role = request.form['role']  # 获取用户选择的角色
        if register_user(userid, password, role):
            flash('注册成功，请登录！')
            return redirect(url_for('login.login'))
        flash('用户ID已存在！')
    return render_template('register.html')

