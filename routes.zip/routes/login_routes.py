from flask import Blueprint, render_template, request, redirect, url_for, flash
from services.user_service import authenticate_user, authenticate_advisor

# 创建蓝图
login_bp = Blueprint('login', __name__)

@login_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        userid = request.form.get('userid')  # 获取表单中的 userid
        password = request.form.get('password')  # 获取表单中的 password
        role = request.form.get('role')  # 获取表单中的角色
        advisor_id = request.form.get('advisor_id')  # 导师 ID，仅在角色为导师时需要

        # 验证用户
        user = authenticate_user(userid, password)
        if user:
            if role == '学生用户':
                return redirect(url_for('candidate_page', userid=userid))
            elif role == '学科管理员':
                return redirect(url_for('admin_page'))
            elif role == '导师':
                if not advisor_id or not authenticate_advisor(advisor_id):
                    flash("无效的导师 ID")
                    return redirect(url_for('login.login'))
                return redirect(url_for('advisor_page', advisor_id=advisor_id))
            else:
                flash("未知角色，无法登录！")
        else:
            flash("用户名或密码错误")
    return render_template('login.html')
