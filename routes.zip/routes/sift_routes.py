from flask import Blueprint, jsonify, request
from dao.applicant_dao import ApplicantDAO  # 确保导入 ApplicantDAO
from services.applicant_service import ApplicantService

sift_bp = Blueprint('sift', __name__)

@sift_bp.route('/apply_sift', methods=['POST'], endpoint='sift_apply_sift')
def apply_sift():
    """
    应用筛选规则接口
    """
    try:
        result = ApplicantService.apply_sift()
        return jsonify(result)
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500



@sift_bp.route('/retest_info', methods=['GET'])
def get_retest_info_sift():
    # 函数逻辑
    """
    获取 Retest_Info 表的所有数据，可选支持 sift 筛选、排序，并允许分页
    """
    try:
        # 获取可选参数
        page = request.args.get('page', type=int)  # 当前页码（可选）
        limit = request.args.get('limit', type=int)  # 每页记录数（可选）
        sift = request.args.get('sift', None, type=int)  # 筛选条件（可选）
        sort_by = request.args.get('sort_by', default='candidate_id', type=str)  # 排序字段
        sort_order = request.args.get('sort_order', default='asc', type=str)  # 排序方向

        # 验证 sift 参数
        if sift is not None and sift not in [0, 1]:
            return jsonify({'status': 'error', 'message': '筛选条件 sift 只能为 0 或 1'}), 400

        # 验证排序方向
        if sort_order not in ['asc', 'desc']:
            return jsonify({'status': 'error', 'message': '排序顺序必须为 asc 或 desc'}), 400

        # 调用 DAO 方法获取所有数据
        data = ApplicantDAO.fetch_retest_info()

        # 筛选 sift 数据
        if sift is not None:
            data = [row for row in data if row['sift'] == sift]

        # 排序数据
        data = sorted(
            data,
            key=lambda x: x.get(sort_by, 0),  # 默认按 0 排序
            reverse=(sort_order == 'desc')  # 降序
        )

        # 如果未传分页参数，返回所有数据
        if not page or not limit:
            return jsonify({
                'status': 'success',
                'data': data,
                'total': len(data)
            })

        # 分页处理
        total = len(data)  # 总记录数
        start = (page - 1) * limit
        end = start + limit
        paginated_data = data[start:end]

        # 计算总页数
        total_pages = (total + limit - 1) // limit

        # 返回分页结果
        return jsonify({
            'status': 'success',
            'data': paginated_data,
            'page': page,
            'limit': limit,
            'total': total,
            'total_pages': total_pages
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500
@sift_bp.route('/apply_sift', methods=['POST'])
def apply_sift():
    """
    应用筛选规则接口
    """
    try:
        result = ApplicantService.apply_sift()
        return jsonify(result)
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500


@sift_bp.route('/retest_info', methods=['GET'])
def get_retest_info():
    """
    分页和筛选获取 Retest_Info 表的信息
    """
    try:
        # 获取分页参数，默认第一页，10条记录
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 10))

        # 获取筛选条件，默认为 None（不筛选）
        sift = request.args.get('sift', None)
        if sift is not None:
            sift = int(sift)

        # 调用服务层方法
        data = ApplicantService.get_retest_info(page, limit, sift)

        # 返回分页数据
        return jsonify({
            'status': 'success',
            'data': data['records'],
            'total': data['total'],
            'page': page,
            'limit': limit
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500