from flask import Blueprint, render_template
from services.applicant_service import ApplicantService

applicant_bp = Blueprint('applicant', __name__)

@applicant_bp.route('/candidates', methods=['GET'])
def get_all_candidates_page():
    """
    渲染 Candidate 表的所有数据
    """
    try:
        candidates = ApplicantService.get_all_candidates()
        print(f"Page Route: Retrieved {len(candidates)} candidates")  # 调试日志
        print(f"Page Data: {candidates}")  # 打印数据
        return render_template('candidates.html', data=candidates)
    except Exception as e:
        print(f"Page Route Error: {str(e)}")  # 错误日志
        return render_template('error.html', error_message=str(e)), 500
