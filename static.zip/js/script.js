// 表单验证
function validateForm(formType) {
    const userid = document.getElementById('userid').value.trim();
    const password = document.getElementById('password').value.trim();

    // 验证用户ID是否是三位数字
    if (!/^\d{3}$/.test(userid)) {
        alert('用户ID必须是三位数字！');
        return false;
    }

    // 验证密码长度
    if (password.length < 6) {
        alert('密码长度不能少于6个字符！');
        return false;
    }

    return true;
}

// 页面加载完成后设置事件监听器
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');

    if (loginForm) {
        loginForm.addEventListener('submit', (event) => {
            if (!validateForm('login')) {
                event.preventDefault();
            }
        });
    }
});
